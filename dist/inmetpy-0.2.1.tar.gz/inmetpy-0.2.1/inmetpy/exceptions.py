class RequestTooLarge(Exception):
    pass
